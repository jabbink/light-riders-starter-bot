// // Copyright 2016 riddles.io (developers@riddles.io)

//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at

//        http://www.apache.org/licenses/LICENSE-2.0

//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//  
//    For the full copyright and license information, please view the LICENSE
//    file that was distributed with this source code.

package field


/**
 * field.Field

 * Handles everything that has to do with the field, such
 * as storing the current state and performing calculations
 * on the field.

 * @author Jim van Eeden <jim></jim>@riddles.io>
 */

data class Point(var x: Int, var y: Int)

enum class FieldType {
  EMPTY, WALL, MY_HEAD, ENEMY_HEAD
}

class Field {

  var myId = 0
  var width = 0
  var height = 0
  private var field: Array<Array<FieldType>>? = null

  var myPosition: Point? = null
    private set

  /**
   * Initializes and clears field
   * @throws Exception exception
   */
  @Throws(Exception::class)
  fun initField() {
    /*try {
      this.field = Array(width) { Array(height, { FieldType.EMPTY }) }
    } catch (e: Exception) {
      throw Exception("Error: trying to initialize field while field " + "settings have not been parsed yet.")
    }

    clearField()*/
  }

  /**
   * Clears the field
   */
  private fun clearField() {
    /*for (y in 0..this.height - 1) {
      for (x in 0..this.width - 1) {
        this.field!![x][y] = FieldType.EMPTY
      }
    }

    this.myPosition = null*/
  }

  /**
   * Parse field from comma separated String
   * @param s input from engine
   */
  fun parseFromString(s: String) {
    /*clearField()

    val split = s.split(",")
    var x = 0
    var y = 0

    split.forEach {
      field!![x][y] = when (it) {
        "." -> FieldType.EMPTY
        "x" -> FieldType.WALL
        myId.toString() -> {
          myPosition = Point(x, y)
          FieldType.MY_HEAD
        }
        else -> FieldType.ENEMY_HEAD
      }

      if (++x == this.width) {
        x = 0
        y++
      }
    }*/
  }
}